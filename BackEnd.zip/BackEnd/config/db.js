const mongoose = require('mongoose');
const config = require('./config');

const connectDB = async () => {
  try {
    const connection = await mongoose.connect(config.mongoURI, {
    });
    console.log('MongoDB Connected to database:', connection.connection.db.databaseName);
  } catch (err) {
    console.error('MongoDB Connection Error:', err.message);
    process.exit(1);
  }
};

module.exports = connectDB;
