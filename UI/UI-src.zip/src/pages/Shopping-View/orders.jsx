import React from 'react';
import ShoppingOrders from '../../Components/shopping/orders';

function OrdersPage() {
  return <ShoppingOrders />;
}

export default OrdersPage;
