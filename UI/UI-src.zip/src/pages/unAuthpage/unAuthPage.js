import React from 'react'

export default function unAuthPage() {
  return (
    <div>
        <h1> You are not permitted to enter this page! </h1>
    </div>
  )
}
